package com.example.demo.response;

public class RegisterResponse extends Response {

    public  RegisterResponse(boolean success, String tag, String message) {
        super(success,tag, message);
    }
}
