package com.example.demo.service;

import com.example.demo.request.RegisterRequest;
import com.example.demo.request.UpdateRequest;
import com.example.demo.response.RegisterResponse;
import com.example.demo.response.UpdateResponse;

public interface StudentService {

    RegisterResponse registerStudent (RegisterRequest registerRequest);
    UpdateResponse updateStudent (UpdateRequest updateRequest);

}
