package com.example.demo.controller;

import com.example.demo.request.RegisterRequest;
import com.example.demo.request.UpdateRequest;
import com.example.demo.response.RegisterResponse;
import com.example.demo.response.UpdateResponse;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping( method = RequestMethod.POST,path = "/user")
public class StudentController {

    @Autowired
    StudentService studentService;

    @PostMapping(path="/register")
    public RegisterResponse registerStudent (@RequestBody RegisterRequest registerRequest ){
        RegisterResponse registerResponse = studentService.registerStudent(registerRequest);
        return registerResponse;
    }

    @PostMapping(path="/update")
    public UpdateResponse updateStudent (@RequestBody UpdateRequest updateRequest){
        UpdateResponse updateResponse =  studentService.updateStudent(updateRequest);
        return updateResponse;

    }


}
