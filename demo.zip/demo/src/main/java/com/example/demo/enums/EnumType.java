package com.example.demo.enums;

public interface EnumType {

    String getString();

}
