package com.example.demo.response;

public class UpdateResponse extends  Response {

    public UpdateResponse(boolean success, String tag, String message) {
        super(success, tag, message);
    }
}
